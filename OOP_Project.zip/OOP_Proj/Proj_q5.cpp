#include "AttributedGraph1_q5.h"

int main() {
    class SimpleGraph {
public:
    virtual void sendMessage() const = 0; // Pure virtual function

    void Print() const {
        std::cout << "Printing data from SimpleGraph" << std::endl;
    }
};

class DerivedGraph1 : public SimpleGraph {
public:
    void sendMessage() const override {
        std::cout << "Sending message from DerivedGraph1" << std::endl;
    }
};

class DerivedGraph2 : public SimpleGraph {
public:
    void sendMessage() const override {
        std::cout << "Sending message from DerivedGraph2" << std::endl;
    }
};


    AttributedGraph1 graph;
    graph.sendMessage();

    return 0;
}