#include <iostream>
#include "AttributedGraph2.h"

using namespace std;

AttributedGraph2::AttributedGraph2() : SimpleGraph() {
    // Additional initialization for AttributedGraph2
}

AttributedGraph2::AttributedGraph2(int nodes, int edges) : SimpleGraph(nodes, edges) {
    // Additional initialization for AttributedGraph2
}

void AttributedGraph2::sendMessage() {
    cout << "Sending message in AttributedGraph2" << endl;
}

AttributedGraph2::~AttributedGraph2() {
    // Cleanup for AttributedGraph2
}