#include <iostream>
#include "AttributedGraph1.h"

using namespace std;

AttributedGraph1::AttributedGraph1() : SimpleGraph() {
    // Additional initialization for AttributedGraph1
}

AttributedGraph1::AttributedGraph1(int nodes, int edges) : SimpleGraph(nodes, edges) {
    // Additional initialization for AttributedGraph1
}

void AttributedGraph1::sendMessage() {
    cout << "Sending message in AttributedGraph1" << endl;
}

AttributedGraph1::~AttributedGraph1() {
    // Cleanup for AttributedGraph1
}