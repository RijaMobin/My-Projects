

#ifndef ATTRIBUTEDWEIGHTEDGRAPH_H
#define ATTRIBUTEDWEIGHTEDGRAPH_H
#include "AttributedWeightedGraph.h"
#include "AttributedGraph1.h"
using namespace std;
class AttributedWeightedGraph : public AttributedGraph1 {
private:
    int** weights;//2D array

public:
    AttributedWeightedGraph(int n);
    ~AttributedWeightedGraph();

    void appendWeight(int nodeId1, int nodeId2, int weight);
};

#endif  // ATTRIBUTEDWEIGHTEDGRAPH_H